var waitReply = 0;
sendRegistration = function() {
	var upass = $('#reg_password').val();
	var uuser = $('#reg_username').val();
	var uemail = $('#reg_email').val();
	if(upass == '' || uuser == ''){
		callSaved("empty field", 3);
		return false;
	}
	else if (/^\s+$/.test($('#reg_username').val())){
		callSaved("empty field", 3);
		$('#reg_username').val("");
		return false;
	}
	else if (/^\s+$/.test($('#reg_password').val())){
		callSaved("empty field", 3);
		$('#reg_password').val("");
		return false;
	}
	else {
		if(waitReply == 0){
			waitReply = 1;
			$.post('action_1', {
				type: 1,
				password: upass,
				username: uuser,
				email: uemail,
				}, function(response) {
					if(response == 2){
						callSaved("ERROR", 3);
						$('#reg_password').val("");
						$('#reg_username').val("");
						$('#reg_email').val("");	
					}
					else if (response == 3){
						callSaved("ERROR", 3);
						$('#reg_password').val("");
						$('#reg_username').val("");
						$('#reg_email').val("");
					}
					else if (response == 4){
						callSaved("Username is invalid", 3);
						$('#reg_username').val("");
					}
					else if (response == 6){
						callSaved("Email is invalid", 3);
						$('#reg_email').val("");
					}
					else if (response == 10){
						callSaved("Email or Username Already Registered", 3);
						$('#reg_email').val("");
					}
					else if (response == 14){
						callSaved("Error", 3);
					}
					else if (response == 17){
						callSaved("Password is too short", 3);
						$('#reg_password').val("");
					}
					else if (response == 1){
						location.reload();
					}
					else {
						waitReply = 0;
						return false;
					}
					waitReply = 0;
			});
		}
		else{
			return false;
		}
	}
}

sendLogin = function(){
	var upass = $('#user_password').val();
	var uuser = $('#user_username').val();
	if(upass == '' || uuser == ''){
		callSaved("Field is empty", 3);
		return false;
	}
	else if (/^\s+$/.test($('#user_password').val())){
		callSaved("Field is empty", 3);
		$('#user_password').val("");
		return false;
	}
	else if (/^\s+$/.test($('#user_username').val())){
		callSaved("field is empty", 3);
		$('#user_username').val("");
		return false;
	}
	else {
		if(waitReply == 0){
			waitReply = 1;
			$.post('action_1', {
				password: upass, 
				username: uuser,
				type: 2
				}, function(response) {
					if(response == 1){
						callSaved("Login details are wrong", 3);
						$('#user_password').val("");
					}
					else if (response == 2){
						callSaved("Login details are wrong", 3);
						$('#user_password').val("");
					}
					else if (response == 3){
						location.reload();
					}
					waitReply = 0;
			});
		}
		else {
			return false;
		}
	}
}