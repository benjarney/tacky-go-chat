showModal = function(r){
	hideModal();
	$('.small_modal_in').css('max-width', '400px');
	$('#small_modal_content').html(r);
	$('#small_modal').show();
}

hideModal = function(){
	$('#small_modal_content').html('');
	$('#small_modal').hide();
}

getModal = function(page) {
	$.post('modal', {
		modalPage: page,
	}, function(response){
		showModal(response);
	});
}

var curCall = '';
callSaved = function(text, type){
	var s = 3000;
	if(type == 1){
		s = 1000;
	}
	if(text == curCall && $('.saved_data:visible').length){
		return false;
	}
	else {
		if(type == 1){
			$('.saved_data').removeClass('saved_warn saved_error').addClass('saved_ok');
		}
		if(type == 2){
			$('.saved_data').removeClass('saved_ok saved_error').addClass('saved_warn');
		}
		if(type == 3){
			$('.saved_data').removeClass('saved_warn saved_ok').addClass('saved_error');
		}
		$('.saved_span').text(text);
		$('.saved_data').fadeIn(300).delay(s).fadeOut();
		curCall = text;
	}
}



$(document).ready(function(){
	$(document).on('click', '.close_modal, .cancel_modal', function(){
		hideModal();
	});
	
});