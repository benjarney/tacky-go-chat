var fload = 0;
var cAction = 0;
var moreMain = 1;
var lastPost = 0;
var waitReply = 0;
var speed = 3000;
chatReload = function(){
	logsControl();

	$.ajax({
		url: "action_2",
		type: "post",
		cache: false,
		timeout: speed,
		dataType: "json",
		data: {
			fload: fload,
			caction: cAction,
			last: lastPost,
			token: utk,
			userid: uid
		},
		success: function(response){
			if("check" in response){
				if(response.check == 99){
					location.reload();
					return false;
				}
				else if(response.check == 199){
					return false;
				}
			}
			else{
				var mLogs = response.mlogs;
				var mLast = response.mlast;
				var cact = response.cact;

				if(mLogs != ""){
					$("#chat_logs_container").append(mLogs);
				}

				scrollIt(fload);

				fload = 1;
				lastPost = mLast;
				cAction = cact;
			}
		},
		error: function(){
			return false;
		}
	});
};

logsControl = function(){
	if($("#show_chat").attr("value") == 1){
		var countLog = $(".ch_logs").length;
		var countLimit = 60;
		var countDiff = countLog - countLimit;

		if(countDiff > 0 && countDiff % 2 === 0){
			$("#chat_logs_container").find(".ch_logs:lt(" + countDiff + ")").remove();
			moreMain = 1;
		}
	}
};

scrollIt = function(f){
	var t = $("#show_chat");

	if(f == 0 || $("#show_chat").attr("value") == 1){
		t.scrollTop(t.prop("scrollHeight"));
	}
};

processChatPost = function(message){
	$.ajax({
		url: "action_2",
		type: "POST",
		data: {
			content: message,
			token: utk,
			userid: uid
		},
		success: function(response){
			if(response == ""){
				waitReply = 0;
				return;
			}

			$("#chat_logs_container").append(response);

			var postedLog = $("#chat_logs_container .ch_logs").last();
			var postedID = parseInt(postedLog.attr("data"), 10);

			if(!isNaN(postedID)){
				lastPost = postedID;
			}

			fload = 1;

			scrollIt(0);
			waitReply = 0;
		},
		error: function(xhr){
			console.log("Message send failed:", xhr.status, xhr.responseText);
			waitReply = 0;
		}
	});
};


adjustHeight = function(){
	var winHeight = $(window).height();
	var topChatHeight = $(".chat_input_container").outerHeight(true);
	var cb = winHeight - topChatHeight;

	$("#warp_show_chat").css({
		"height": cb
	});
};

chatInput = function(){
	$("#content").val("");
};

$(document).ready(function(){
	$("#content, #submit_button").prop("disabled", false);

	adjustHeight();
	chatReload();

	chatLog = setInterval(function(){
		chatReload();
	}, 3000);

	$("#main_input").submit(function(event){
		event.preventDefault();

		var message = $("#content").val();

		if(message == ""){
			return false;
		}

		if(/^\s+$/.test(message)){
			chatInput();
			return false;
		}

		if(waitReply == 0){
			waitReply = 1;
			chatInput();
			processChatPost(message);
		}

		return false;
	});

	$(window).resize(function(){
		adjustHeight();
	});
});