package main

import (
	"net/http"
	"html/template"
	"regexp"
	"database/sql"
	"strconv"
	"strings"
	"time"
	"fmt"
	
	_ "github.com/go-sql-driver/mysql"
)

type PageData struct {
	Userid   int
	Username string
	Password string
}

var db *sql.DB

func main() {
	
	db, _ = sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/chatapp")
	cssServer := http.FileServer(http.Dir("css"))
	http.Handle("/css/", http.StripPrefix("/css/", cssServer))
	jsServer := http.FileServer(http.Dir("js"))
	http.Handle("/js/", http.StripPrefix("/js/", jsServer))
		
    http.HandleFunc("/", loadMainPage)
	http.HandleFunc("/modal", openModal)
	http.HandleFunc("/action_1", loginactions)
	http.HandleFunc("/action_2", mainactions)
    http.ListenAndServe(":8080", nil)
}

func enableCORS(w http.ResponseWriter) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
}

func loadMainPage(w http.ResponseWriter, r *http.Request) {
	uid, uname, _, upass, islogged := getUser(r)
	
	if (islogged == false) {
		loadLoginPage(w, r)
		return
	}else{
		loadChatPage(w, r, uid, uname, upass)
		return
	}
}

func loadChatPage(w http.ResponseWriter, r *http.Request, uid int, uname string, upass string) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")

	Htemp, err := template.ParseFiles("templates/chat.html")
	if err != nil {
		return
	}

	data := PageData{
		Userid:   uid,
		Username: uname,
		Password: upass,
	}

	err = Htemp.Execute(w, data)
	if err != nil {
		return
	}

	return
}

func loadLoginPage(w http.ResponseWriter, r *http.Request){
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	Htemp, err := template.ParseFiles("templates/login.html")
	
	if err != nil {
		return
	}
	 
	data := PageData{
    }

    err = Htemp.Execute(w, data)
    if err != nil {
        return
    }

	return
}

func openModal(w http.ResponseWriter, r *http.Request){
	enableCORS(w)

	if r.Method == http.MethodOptions {
		return 
	}

	modalPage := r.FormValue("modalPage")

	if modalPage == "" {
		return 
	}

	Htemp, err := template.ParseFiles(modalPage)

	if err != nil {
		return
	}
	
	data := PageData{
    }
	
	err = Htemp.Execute(w, data)

	if err != nil {
		return
	}

	return
}

func loginactions(w http.ResponseWriter, r *http.Request){
	if r.Method == http.MethodOptions {
		return 
	}

	lrt := r.FormValue("type")

	_, _, _, _, islogged := getUser(r)

	if (islogged == true){
		return
	}
	
	if lrt == "" {
		return 
	}else if(lrt == "1"){
		var username string = r.FormValue("username")
		var password string = r.FormValue("password")
		var email string = r.FormValue("email")
		var userid int

		var usernameRegex = regexp.MustCompile(`^[a-zA-Z0-9_]+$`)
		var emailRegex = regexp.MustCompile(`^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$`)

		if(len(username)>15 || len(username)<3 || !usernameRegex.MatchString(username) ) {
			w.Write([]byte("4"))
			return
		}

		if(len(password)<7) {
			w.Write([]byte("17"))
			return 
		}

		if (len(email)>30 || len(email)<5 || !emailRegex.MatchString(email)) {
			w.Write([]byte("6"))
			return
		}
		
		err1 := db.QueryRow(
			"SELECT userid FROM users WHERE email = ? OR username = ?",
			email,
			username,
		).Scan(&userid)

		if err1 == nil {
			w.Write([]byte("10"))
			return
		}
		
		result, err := db.Exec(
			"INSERT INTO users (username, password, email) VALUES (?, ?, ?)",
			username,
			password,
			email,
		)

		if err != nil {
			w.Write([]byte("2"))
			return 
		}else{
			userid, _ := result.LastInsertId()

			http.SetCookie(w, &http.Cookie{
				Name:  "userid",
				Value: strconv.FormatInt(userid, 10),
			})

			http.SetCookie(w, &http.Cookie{
				Name:  "password",
				Value: password,
			})

			w.Write([]byte("1"))
			return
		}
	}else if(lrt == "2"){
		username := strings.ToLower(r.FormValue("username"))
		var password string = r.FormValue("password")
		var userid string

		err1 := db.QueryRow(
			"SELECT userid FROM users WHERE (LOWER(email) = ? OR LOWER(username)= ?) AND password = ?",
			username,
			username,
			password,
		).Scan(&userid)

		if err1 != nil {
			w.Write([]byte("2"))
			return
		}else{
			http.SetCookie(w, &http.Cookie{
				Name:  "userid",
				Value: userid,
			})

			http.SetCookie(w, &http.Cookie{
				Name:  "password",
				Value: password,
			})

			w.Write([]byte("3"))
			return
		}
	}
}

func mainactions(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodOptions {
		return
	}

	password := r.FormValue("token")

	userid, err := strconv.Atoi(r.FormValue("userid"))
	if err != nil {
		return
	}

	var username string
	var last_id_set int64

	err = db.QueryRow(
		"SELECT users.username, setting.last_id FROM users CROSS JOIN setting WHERE users.userid = ? AND users.password = ?",
		userid,
		password,
	).Scan(&username, &last_id_set)

	if err != nil {
		return
	}

	if r.FormValue("content") != "" {
		content := r.FormValue("content")

		if len(content) > 500 {
			return
		}

		tx, err := db.Begin()
		if err != nil {
			return
		}

		result, err := tx.Exec(
			"INSERT INTO messages (user_id, message) VALUES (?, ?)",
			userid,
			content,
		)

		if err != nil {
			tx.Rollback()
			return
		}

		lastid, err := result.LastInsertId()
		if err != nil {
			tx.Rollback()
			return
		}

		_, err = tx.Exec(
			"UPDATE setting SET last_id = ?",
			lastid,
		)

		if err != nil {
			tx.Rollback()
			return
		}

		err = tx.Commit()
		if err != nil {
			return
		}

		fmt.Fprintf(w, `<li id="log%d" data="%d" class="ch_logs">
			<div class="my_text">
				<div class="btable">
					<div class="cname"><span class="username">%s</span></div>
					<div class="cdate">%s</div>
				</div>
				<div class="chat_message">%s</div>
			</div>
		</li>`,
			lastid,
			lastid,
			username,
			time.Now().Format("1/02 03:04"),
			template.HTMLEscapeString(content),
		)

		return
	}

	fload := r.FormValue("fload")
	caction := r.FormValue("caction")

	last, err := strconv.ParseInt(r.FormValue("last"), 10, 64)

	if err != nil {
		last = 0
	}

	if caction == "" {
		caction = "0"
	}

	var rows *sql.Rows

	if fload == "0" {
		rows, err = db.Query(`
			SELECT messages.id, messages.user_id, users.username, messages.message, messages.created_at
			FROM messages
			INNER JOIN users ON users.userid = messages.user_id
			ORDER BY messages.id DESC
			LIMIT 20
		`)
	}else if fload == "1" && last_id_set > last {
		rows, err = db.Query(`
			SELECT messages.id, messages.user_id, users.username, messages.message, messages.created_at
			FROM messages
			INNER JOIN users ON users.userid = messages.user_id
			WHERE messages.id > ?
			ORDER BY messages.id ASC
		`, last)
	}else{
		w.Header().Set("Content-Type", "application/json")

		fmt.Fprintf(w, `{"mlogs":"","mlast":%d,"cact":%s}`,
			last,
			caction,
		)

		return
	}

	if err != nil {
		return
	}

	defer rows.Close()

	var mlogs string
	var mlast int64 = last

	if fload == "0" {
		var logs []string
		var newestID int64

		for rows.Next() {
			var id int64
			var messageUserID int
			var messageUsername string
			var message string
			var created string

			err := rows.Scan(
				&id,
				&messageUserID,
				&messageUsername,
				&message,
				&created,
			)

			if err != nil {
				return
			}

			logs = append(logs, createLog(
				id,
				messageUserID,
				messageUsername,
				message,
				created,
			))

			if id > newestID {
				newestID = id
			}
		}

		for i := len(logs) - 1; i >= 0; i-- {
			mlogs += logs[i]
		}

		if newestID > 0 {
			mlast = newestID
		}
	}else{
		for rows.Next() {
			var id int64
			var messageUserID int
			var messageUsername string
			var message string
			var created string

			err := rows.Scan(
				&id,
				&messageUserID,
				&messageUsername,
				&message,
				&created,
			)

			if err != nil {
				return
			}

			mlogs += createLog(
				id,
				messageUserID,
				messageUsername,
				message,
				created,
			)

			if id > mlast {
				mlast = id
			}
		}
	}

	w.Header().Set("Content-Type", "application/json")

	fmt.Fprintf(w, `{"mlogs":%q,"mlast":%d,"cact":%s}`,
		mlogs,
		mlast,
		caction,
	)
}

func getUser(r *http.Request) (int, string, string, string, bool) {
	useridck, err1 := r.Cookie("userid")
	passwordck, err2 := r.Cookie("password")

	if err1 != nil || err2 != nil {
		return 0, "", "", "", false
	}

	var userid int
	var username string
	var email string
	var password string

	err := db.QueryRow(
		"SELECT userid, username, email, password FROM users WHERE userid = ? AND password = ?",
		useridck.Value,
		passwordck.Value,
	).Scan(&userid, &username, &email, &password)

	if err != nil {
		return 0, "", "", "", false
	}

	return userid, username, email, password, true
}

func createLog(id int64, userid int, username string, message string, created string) string {
	return fmt.Sprintf(`<li id="log%d" data="%d" class="ch_logs">
		<div class="my_text">
			<div class="btable">
				<div class="cname">
					<span class="username">%s</span>
				</div>
				<div class="cdate">%s</div>
			</div>
			<div class="chat_message">%s</div>
		</div>
	</li>`,
		id,
		id,
		username,
		created,
		message,
	)
}